[[11 Janvier 2025]]
16/01/25 Idée scenario Jordan :
Le hero aurait pour ennemie les religieux de l'orde de l'aube éthérée. Mais aussi les Gobelins.

Les Gobelins sont aggressif avec tout les etre intelligents dans tout les cas. Mais du fait que le héro possede les 4 éléments et donc le potentiel d'incarner Le Chaos les Gobelins poursuivrais le heros. 