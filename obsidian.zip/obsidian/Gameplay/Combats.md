- Pas de mana, simplement des cool down plus ou moins longs pour chaque sort.
- 4 éléments pour le héros, 1 pour les ennemies
- ATH avec 4 slot de sorts (dont 4 de plus si il a les bonnes combinaisons de sorts)

Les éléments :
- Le feu ( offensif)
- L'eau (Soins)
- Le vent (déplacement du héros ou des ennemis)
- La terre (Protection ou obstacle)

_<span style="color:orange">Chaque élément sert une utilité (attaque, défense, soutien, dé/placement), mais parfois un élément peux se pencher vers une utilité "secondaire"
pour l'exemple :_</span>

Le feux est offensif, donc le premier sort est une boule de feu a dégâts direct. par la suite pourquoi pas avoir un sort offensif mais aussi un peu protecteur.
Comme par exemple "aura du phénix" Qui fais des dégâts aux ennemies proche tout en régénérant lentement les pv. Ca permettrais une dynamique des sorts moins ennuyeuse et prévisible (surtout si les joueurs ne connaissent pas les futur sort déblocable).

Donc finalement plus le joueurs progressera plus les sort deviendrons multi-élémentaire.

<span style="color:orange;font-weight:800">Quand le joueur ajoute 2 sorts d'élements différents en particulier dans sons deck, le joueur à la possibilité de débloqué un sort spécial qui mélange les effet et en fait un sort plus puissant.</span>

Idée de sorts :

**<span style="color:red">Feu</span>** : 
- Feu cinglant : un simple fouet de feu.
- SuperNova : Une sort complexe mélangeant le feu et le vent. Le joueur émane de son corps une violente explosion de feu, faisant des dégâts colossale et repoussant tout les ennemies trop proche de lui.
**<span style="color:cyan">Eau</span>** : 
- Nettoyage des plaies : un simple sort de soins.
**<span style="color:brown">Terre</span>** : 
- Carapace : un simple sort de réduction de dégâts
- Exosquelette sylphide : Un sort complexe mélangeant le vent et la terre. ¨Il sert principalement a réduire les dégâts, mais il permet aussi au joueur d'esquiver (avec un cool down et une touche spécifique) visuellement le joueurs serait recouvert de quelques morceau d'armure tenu grâce au vent
**<span style="color:green">Vent</span>** : 
- Repli aérien : simple sort d'esquive vers la direction dans la quelle veux se diriger le joueur
- Zéphyr tellurique : Sort complexe mélangeant le vent et la terre. Le joueurs d'un coup de pied fait sortir des morceau de roche du sol, puis avec l'aide du vent les soulever et les projeter sur l'ennemi.