# Jeu Solo
### type et principe de jeu
jeu dans le type power level (on débute comme un simple personnage et de plus en plus on acquière des pouvoirs destructeurs). 
Le jeu est semi-ouvert avec des zones plus ou moins grande et plus ou moins fournis

### Gameplay
- inventaire basique (très peu ou pas d'équipement, seulement des items de soutiens)
- Leveling basique : Pas de points d'xp, pas de level (géré uniquement en back-end)

### Doublage
Essayer de faire un jeu avec des voix FR

### Scénario 
On débute dans un univers fantasy sympa, et plus le jeu avance, plus le monde autour de nous deviens sombre et chaotique. Le personnage principal est un adepte de la religion dominante du monde mais il se rend compte petit à petit que sa vie parfaite ne sert qu'a assouvir les dessein des dirigeants. Peu à peu il sombre dans la folie destructrice. Plutot détruire ce monde que d'en être spectateur.

*La religion*
La religion régis le pays  entier (foie, justice, politique). Les gens y sont habitués et l'accepte entièrement. 

### Idées
- La magie sacrée est la seule magie autorisée dans le monde et, uniquement utilisé par l'église.
- Les autres type de magie sont proscrites car selon l'église, elle amène la destruction du monde (ce qui est juste car le joueur deviens destructeur de monde)
- Le joueur va rencontré une jeune femme d'église gentilles et attentionnée (donc pas corrompue). Il va ensuite la surprendre venir en aide a des gens dans le besoin, malgré les réticence de l'église. Par la suite au fur et a mesure que le joueur sombre dans la folie, on rencontre plusieurs fois cette femme qui est le miroir du héros.
- Le personnage principal, à la force de se battre contre l'église, perd toute conscience et deviens ce contre quoi il se battait au début.
