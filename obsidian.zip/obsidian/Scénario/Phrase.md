"Un jeune homme simple et normal se confronte à la religion qui parait idéale mais qui domine méchamment son royaume."

Cette phrase de départ est ensuite étendue en [[Paragraphe]]
