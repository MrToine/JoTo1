
- La magie sacrée est la seule magie autorisée dans le monde et, uniquement par l'église.
- Les autres type de magie sont proscrit car selon l'église, elle amène la destruction du monde (ce qui est juste car le joueur deviens destructeur de monde)
- L’histoire du jeu avance de jour en jour.
- Dans l'histoire, le héros a pour but d’apprendre la magie afin de devenir suffisamment puissant pour stopper l'Église. Comme prévu il étudiera la magie et les 4 voies élémentaires.
- En début de partie le héros ne connaît aucun sort, il n’est qu’un apprenti du clergé. Il ne maîtrise même pas la magie sacrée. C’est d’ailleurs pour cela qu’il va se tenter à l'apprentissage des éléments.
- A la fin du jeu, le héros maîtrisera tous les éléments au niveau maximum. Pour donner une impression de choix dans la progression des compétences. On peut peut être ajouter un menu d’amélioration (comme un arbre de compétence) Le héros aurait donc le choix a chaque fin de journée entre améliorer le feu, l’eau, la terre ou le vent.

Voir le flocon de neige de l'histoire:
[[Phrase]]
