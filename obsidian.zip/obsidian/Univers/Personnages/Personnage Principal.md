**Age** : La vingtaine
**Taille** : 1m75
**Situation** : Apprenti religieux
**Objectif** : renverser l'ordre religieux qui n'est pas aussi bienfaisant qu'il n'y parait.